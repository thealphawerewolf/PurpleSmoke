//
//  reboot.h
//  jailbreak112
//
//  Created by Sem Voigtländer on 11/04/2018.
//  Copyright © 2018 Jailed Inc. All rights reserved.
//

#ifndef reboot_h
#define reboot_h

#include <stdio.h>
void rebootDevice(void);
#endif /* reboot_h */
