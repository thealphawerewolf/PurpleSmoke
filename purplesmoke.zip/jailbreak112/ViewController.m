//
//  ViewController.m
//  jailbreak112
//
//  Created by Sem Voigtländer on 11/04/2018.
//  Copyright © 2018 Jailed Inc. All rights reserved.
//

#import "ViewController.h"
#import "jailbreak.h"
#import "reboot.h"
@interface ViewController ()
- (IBAction)rebootBtnTap:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    jailbreak();
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)rebootBtnTap:(id)sender {
    rebootDevice();
}
@end
